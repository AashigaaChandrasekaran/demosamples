/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int main()
{
    int size;
    scanf("%d",&size);
    for(int i=1;i<=size;i++){
        for( int j=1;j<=size;j++){
            if(i==j){
                printf("* ");
            }
            else
            {
                printf("  ");
            }
            }printf("\n");
    }
    return 0;
}